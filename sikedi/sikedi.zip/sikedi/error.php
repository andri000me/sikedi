<div class="error-container">
	<div class="well">
		<h1 class="grey lighter smaller">
			<center>
			<span class="blue bigger-125">
				<i class="icon-random"></i>
				Halaman Belum Tersedia
			</span>
			<hr>
			<?php echo $_CONFIG['sysappname'];?>
			</center>
		</h1>
		<hr />
		<div class="row-fluid">
			<div class="center">
				<a href="javascript:self.history.back();" class="btn btn-grey">
					<i class="icon-arrow-left"></i>
					Kembali
				</a>
				<a href="media.php?page=home" class="btn btn-primary">
					<i class="icon-dashboard"></i>
					Home
				</a>
			</div>
		</div>
	</div>
</div>