-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 05, 2019 at 09:48 AM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sikedi`
--

-- --------------------------------------------------------

--
-- Table structure for table `kdkab`
--

DROP TABLE IF EXISTS `kdkab`;
CREATE TABLE IF NOT EXISTS `kdkab` (
  `id_prov` int(2) NOT NULL AUTO_INCREMENT,
  `id_kabkot` int(4) DEFAULT NULL,
  `kk` int(1) NOT NULL DEFAULT '1',
  `nama_kabkot` char(40) NOT NULL,
  `ibukota` varchar(50) NOT NULL,
  `gbr` varchar(50) DEFAULT NULL,
  `kor` text,
  `ppk` varchar(18) DEFAULT NULL,
  `alamat` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id_prov`)
) ENGINE=InnoDB AUTO_INCREMENT=1202 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kdkab`
--

INSERT INTO `kdkab` (`id_prov`, `id_kabkot`, `kk`, `nama_kabkot`, `ibukota`, `gbr`, `kor`, `ppk`, `alamat`) VALUES
(1, 1200, 0, 'Sumatera Utara', 'Medan', '', '', '196512101987021001', 'Jl. Gatot Subroto No.4'),
(2, 1201, 1, 'Nias', 'Gido', '', '', NULL, NULL),
(3, 1202, 1, 'Mandailing Natal', 'Panyabungan', '', '', '', ''),
(4, 1203, 1, 'Tapanuli Selatan', 'Padangsidimpuan', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `kendi`
--

DROP TABLE IF EXISTS `kendi`;
CREATE TABLE IF NOT EXISTS `kendi` (
  `bId` int(20) NOT NULL AUTO_INCREMENT,
  `kdkab` int(4) NOT NULL,
  `bkode` varchar(50) NOT NULL,
  `bjenis` int(11) NOT NULL,
  `bmerek` int(11) NOT NULL,
  `btipe` int(11) NOT NULL,
  `no_mesin` char(50) DEFAULT NULL,
  `no_rangka` varchar(50) DEFAULT NULL,
  `no_plat` varchar(10) NOT NULL,
  `no_bpkb` varchar(50) NOT NULL,
  `bpemegang` varchar(50) NOT NULL,
  `bkondisi` int(1) DEFAULT '1',
  `thn_per` year(4) NOT NULL,
  `harga_per` int(10) DEFAULT NULL,
  `ket` varchar(255) DEFAULT NULL,
  `foto` varchar(50) DEFAULT NULL,
  `pagu` int(11) DEFAULT '3700000',
  `onCreate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `onUpdate` timestamp NULL DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`bId`),
  UNIQUE KEY `bkode_2` (`bkode`),
  KEY `bjenis` (`bjenis`),
  KEY `bmerek` (`bmerek`),
  KEY `btipe` (`btipe`),
  KEY `bkondisi` (`bkondisi`),
  KEY `btgl` (`thn_per`),
  KEY `bkode` (`bkode`)
) ENGINE=InnoDB AUTO_INCREMENT=589 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kendi`
--

INSERT INTO `kendi` (`bId`, `kdkab`, `bkode`, `bjenis`, `bmerek`, `btipe`, `no_mesin`, `no_rangka`, `no_plat`, `no_bpkb`, `bpemegang`, `bkondisi`, `thn_per`, `harga_per`, `ket`, `foto`, `pagu`, `onCreate`, `onUpdate`, `status`) VALUES
(1, 1200, 'KD.1200.0001', 2, 5, 1, 'E271884', 'MHCTBR54F5K271884', 'BK 1239 R', 'D 7824441', '196909191983021001', 1, 2013, 127050000, '', '3413terios2012.jpg', 3515000, '2017-04-29 04:42:04', '2019-05-05 09:45:05', 1),
(2, 1200, 'KD.1200.0002', 2, 4, 9, 'KC11E1254709', 'MH1KC1119AK253184', 'BK 1295 R', 'H-0 2316330', '196701081987031002', 1, 2010, 17026000, '', '2413terios2012.jpg', 33000000, '2017-04-29 07:21:47', '2019-05-05 08:26:41', 1),
(3, 1200, 'KD.1200.0003', 1, 1, 7, 'KC11E1254896', 'MH1KC1110AK253333', 'BK 2454 R', 'H-0 2316331', '196207211982031002', 1, 2010, 17026000, '', '8786jupiterz.jpg', 3515000, '2017-04-29 07:33:09', '2019-05-05 08:25:57', 1),
(4, 1200, 'KD.1200.0004', 1, 2, 4, 'KC11E1254834', 'MH1KC1112AK253219', 'BK 2112 R', 'H-0 2316332', '197905102000121003', 1, 2012, 17026000, '', '3897cb150r.jpg', 3515000, '2017-04-29 07:34:40', '2019-05-05 08:25:41', 1);

-- --------------------------------------------------------

--
-- Table structure for table `kendi_jen`
--

DROP TABLE IF EXISTS `kendi_jen`;
CREATE TABLE IF NOT EXISTS `kendi_jen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jenis` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kendi_jen`
--

INSERT INTO `kendi_jen` (`id`, `jenis`) VALUES
(1, 'Roda Dua'),
(2, 'Roda Empat');

-- --------------------------------------------------------

--
-- Table structure for table `kendi_merk`
--

DROP TABLE IF EXISTS `kendi_merk`;
CREATE TABLE IF NOT EXISTS `kendi_merk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `merek` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kendi_merk`
--

INSERT INTO `kendi_merk` (`id`, `merek`) VALUES
(1, 'Honda'),
(2, 'Yamaha'),
(3, 'Suzuki'),
(4, 'Toyota'),
(5, 'Isuzu'),
(6, 'Daihatsu'),
(7, 'Kawasaki'),
(8, 'Mitsubishi');

-- --------------------------------------------------------

--
-- Table structure for table `kendi_tipe`
--

DROP TABLE IF EXISTS `kendi_tipe`;
CREATE TABLE IF NOT EXISTS `kendi_tipe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jen` int(2) NOT NULL,
  `merek` varchar(25) NOT NULL,
  `tipe` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kendi_tipe`
--

INSERT INTO `kendi_tipe` (`id`, `jen`, `merek`, `tipe`) VALUES
(1, 1, '5', 'Phanter'),
(2, 2, '1', 'Supra X 125'),
(3, 2, '2', 'Vixion'),
(4, 2, '2', 'Jupiter MX'),
(5, 2, '1', 'CB 150R Streetfire'),
(6, 2, '2', 'Jupiter Z'),
(7, 2, '1', 'Supra X 125 CW'),
(8, 1, '3', 'Grand Vitara\n2.0 M/T'),
(9, 1, '6', 'Terios TS-Ekstra'),
(10, 1, '6', 'Xenia'),
(11, 1, '4', 'Kijang'),
(12, 2, '1', 'Honda GL 160 D'),
(13, 2, '1', 'Honda MCB'),
(14, 2, '1', 'Honda Kirana ND 125'),
(15, 2, '1', 'Honda WIN'),
(16, 2, '1', 'Honda Mega Pro'),
(17, 2, '1', 'Honda Mega Pro CW'),
(18, 2, '1', 'Supra X'),
(19, 2, '1', 'Honda Megapro Spoke'),
(20, 2, '1', 'Honda/NF 125 TD'),
(21, 2, '1', 'NF 125 TR1'),
(22, 2, '2', 'Yamaha MX ATCW'),
(23, 2, '1', 'Honda New Mega Pro SW'),
(24, 2, '7', 'Kawasaki (Trail)'),
(25, 1, '8', 'Estrada'),
(26, 2, '7', 'Kawasaki KLX-150'),
(27, 2, '1', 'NF 125 SD'),
(28, 2, '1', 'Supra Fit'),
(29, 2, '3', 'A100');

-- --------------------------------------------------------

--
-- Table structure for table `kendi_uplbukti`
--

DROP TABLE IF EXISTS `kendi_uplbukti`;
CREATE TABLE IF NOT EXISTS `kendi_uplbukti` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `idken` int(5) NOT NULL,
  `thn` varchar(4) NOT NULL,
  `bln` varchar(2) NOT NULL,
  `bukti` varchar(100) NOT NULL,
  `onCreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `onUpdate` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kendi_uplbukti`
--

INSERT INTO `kendi_uplbukti` (`id`, `idken`, `thn`, `bln`, `bukti`, `onCreate`, `onUpdate`) VALUES
(10, 4, '2018', '1', 'kd_4_1605.pdf', '2019-05-05 09:29:47', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ms_pegawai`
--

DROP TABLE IF EXISTS `ms_pegawai`;
CREATE TABLE IF NOT EXISTS `ms_pegawai` (
  `pNip` varchar(18) NOT NULL,
  `kdkab` int(4) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(30) DEFAULT NULL,
  `status` int(1) DEFAULT '4',
  `niplama` varchar(9) DEFAULT NULL,
  `gol` int(1) DEFAULT NULL,
  `jk` int(1) DEFAULT NULL,
  `jb` int(1) DEFAULT NULL,
  `pendidikan` int(1) DEFAULT NULL,
  `lokasi` varchar(120) DEFAULT NULL,
  `hp` varchar(12) DEFAULT NULL,
  `rk` int(1) DEFAULT NULL,
  `kaos` varchar(1) DEFAULT NULL,
  `bank` int(2) DEFAULT NULL,
  `norek` varchar(30) DEFAULT NULL,
  `namarek` varchar(100) DEFAULT NULL,
  `npwp` varchar(30) NOT NULL,
  `st` int(1) NOT NULL DEFAULT '1',
  `onCreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `onUpdate` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`pNip`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ms_pegawai`
--

INSERT INTO `ms_pegawai` (`pNip`, `kdkab`, `nama`, `email`, `status`, `niplama`, `gol`, `jk`, `jb`, `pendidikan`, `lokasi`, `hp`, `rk`, `kaos`, `bank`, `norek`, `namarek`, `npwp`, `st`, `onCreate`, `onUpdate`) VALUES
('196207211982031002', 1200, 'Helmi', 'helmis@gmail.com', 2, '340009765', 8, 1, 2, NULL, 'medan', '081376122234', 2, '6', NULL, NULL, NULL, '', 1, '2017-03-01 05:51:17', '2017-11-27 08:51:20'),
('196512101987021001', 1200, 'Dwi Prawoto', 'dprawoto@gmail.com', 6, '340011659', 10, 1, 3, NULL, 'medan', '081361589233', 2, '4', NULL, NULL, NULL, '', 1, '2017-03-01 05:51:17', '2017-11-27 08:54:32'),
('196701081987031002', 1200, 'Abdul Manaf', 'amanaf@gmail.com', 1, '340011737', 12, 1, 1, 7, 'medan', '082255554456', 2, '5', 1, '-', '-', '-', 1, '2017-03-01 05:51:17', '2019-05-05 09:05:59'),
('196909191983021001', 1200, 'Lauren Nababan', 'lauren@gmail.com', 4, '340010321', 5, 1, 4, 6, '-', '0', 0, '-', 0, '', '', '', 2, '2017-03-01 05:51:17', '2019-02-19 01:07:44'),
('197905102000121003', 1200, 'Dicky Pratama', 'dicky@gmail.com', 3, '340016282', 9, 1, 3, 7, 'medan', '081265055677', 2, '4', 1, '0064646464', '', '', 1, '2017-03-01 05:51:17', '2018-08-22 16:43:24'),
('197909091977121001', 1200, 'Sukirman', 'kirman@gmail.com', 5, '340005542', 6, 1, 5, 7, '-', '082269760200', 1, '1', 1, '-', '-', '-', 1, '2017-03-01 05:51:17', '2019-05-05 09:06:55');

-- --------------------------------------------------------

--
-- Table structure for table `rep_kendi`
--

DROP TABLE IF EXISTS `rep_kendi`;
CREATE TABLE IF NOT EXISTS `rep_kendi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kdkab` varchar(4) NOT NULL,
  `bkode` varchar(20) NOT NULL,
  `tglrep` date NOT NULL,
  `rekrep` varchar(50) NOT NULL,
  `jbbm` int(1) DEFAULT NULL,
  `bbm` float DEFAULT NULL,
  `km` int(11) DEFAULT NULL,
  `biaya` int(12) NOT NULL,
  `detrep` text,
  `onCreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `onUpdate` timestamp NULL DEFAULT NULL,
  `lok` int(1) NOT NULL DEFAULT '2',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rep_kendi`
--

INSERT INTO `rep_kendi` (`id`, `kdkab`, `bkode`, `tglrep`, `rekrep`, `jbbm`, `bbm`, `km`, `biaya`, `detrep`, `onCreate`, `onUpdate`, `lok`) VALUES
(1, '1200', '4', '2019-05-05', 'SPBU 11.201.104', 3, 4.9, 40307, 80000, '', '2019-05-05 08:47:11', '2019-05-05 08:50:43', 2),
(2, '1200', '4', '2019-05-05', 'CV. Sehati Jaya', 1, 0, 0, 235000, '<p>servis</p>\r\n', '2019-05-05 08:56:56', '2019-05-05 08:57:26', 2);

-- --------------------------------------------------------

--
-- Table structure for table `token`
--

DROP TABLE IF EXISTS `token`;
CREATE TABLE IF NOT EXISTS `token` (
  `uUname` varchar(50) NOT NULL,
  `token` varchar(250) NOT NULL,
  `kdkab` varchar(4) NOT NULL,
  `level` varchar(1) NOT NULL,
  `uid` varchar(50) NOT NULL,
  UNIQUE KEY `uUname` (`uUname`,`token`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `uId` varchar(20) NOT NULL,
  `uUname` varchar(50) NOT NULL,
  `uNama` varchar(100) NOT NULL,
  `kdkab` int(4) NOT NULL,
  `uLevel` int(11) DEFAULT '2',
  `uTelp` varchar(20) DEFAULT NULL,
  `uEmail` varchar(50) DEFAULT NULL,
  `uPass` char(32) NOT NULL DEFAULT 'ee11cbb19052e40b07aac0ca060c23ee',
  `uFoto` varchar(255) DEFAULT '11end-user-icon.jpg',
  `uSes` varchar(100) DEFAULT NULL,
  `onCreate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `onUpdate` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`uId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uId`, `uUname`, `uNama`, `kdkab`, `uLevel`, `uTelp`, `uEmail`, `uPass`, `uFoto`, `uSes`, `onCreate`, `onUpdate`) VALUES
('196207211982031002', 'helmi', 'Helmi', 1200, 3, NULL, 'helmis@gmail.com', 'ee11cbb19052e40b07aac0ca060c23ee', '11end-user-icon.jpg', 'v7a9a0n7g22it2hlnm1fbs6pn5', '2019-05-05 08:03:07', NULL),
('196512101987021001 	', 'dprawoto', 'Dwi Prawoto', 1200, 2, NULL, 'dprawoto@gmail.com', 'ee11cbb19052e40b07aac0ca060c23ee', '11end-user-icon.jpg', '6j8d1lgb0p3mn19iotq4ch86o5', '2019-05-05 08:06:31', NULL),
('196701081987031002', 'amanaf', 'Abdul Manaf', 1200, 2, NULL, 'amanaf@gmail.com', 'ee11cbb19052e40b07aac0ca060c23ee', '11end-user-icon.jpg', 'hvndudj6o8i15f5n75r3q15m92', '2019-05-05 08:16:32', NULL),
('196909191983021001', 'lauren', 'Lauren Nababan', 1200, 2, NULL, 'lauren@gmail.com', 'ee11cbb19052e40b07aac0ca060c23ee', '11end-user-icon.jpg', 'fobg8u8l0e054gjm99afi025t1', '2019-05-05 08:18:09', NULL),
('197905102000121003', 'dicky', 'Dicky Pratama', 1200, 0, NULL, 'dicky@gmail.com', 'ee11cbb19052e40b07aac0ca060c23ee', '11end-user-icon.jpg', 'hla85rjeolg9ttmi1j4u2s16r7', '2019-05-05 08:18:47', NULL),
('197909091977121001', 'kirman', 'Sukirman', 1200, 2, NULL, 'kirman@yahoo.com', 'ee11cbb19052e40b07aac0ca060c23ee', '11end-user-icon.jpg', 'nfbtndnedfun5vban39f1mt3b1', '2019-05-05 08:19:13', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `_bank`
--

DROP TABLE IF EXISTS `_bank`;
CREATE TABLE IF NOT EXISTS `_bank` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `bank` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `_bank`
--

INSERT INTO `_bank` (`id`, `bank`) VALUES
(1, 'BNI'),
(2, 'BRI'),
(3, 'Bank Jawa Barat (BJB)'),
(4, 'Mandiri'),
(5, 'Bank Sumut'),
(6, 'BNI Syariah'),
(7, 'Danamon');

-- --------------------------------------------------------

--
-- Table structure for table `_gol`
--

DROP TABLE IF EXISTS `_gol`;
CREATE TABLE IF NOT EXISTS `_gol` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `gol` varchar(25) NOT NULL,
  `pangkat` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `_gol`
--

INSERT INTO `_gol` (`id`, `gol`, `pangkat`) VALUES
(1, 'IIa', 'Pengatur Muda'),
(2, 'IIb', 'Pengatur Muda Tingkat I'),
(3, 'IIc', 'Pengatur'),
(4, 'IId', 'Pengatur Tingkat I'),
(5, 'IIIa', 'Penata Muda'),
(6, 'IIIb', 'Penata Muda Tingkat I'),
(7, 'IIIc', 'Penata'),
(8, 'IIId', 'Penata Tingkat I'),
(9, 'IVa', 'Pembina'),
(10, 'IVb', 'Pembina Tingkat I'),
(11, 'IVc', 'Pembina Utama Muda'),
(12, 'IVd', 'Pembina Utama Madya'),
(13, 'IVe', 'Pembina Utama');

-- --------------------------------------------------------

--
-- Table structure for table `_jabatan`
--

DROP TABLE IF EXISTS `_jabatan`;
CREATE TABLE IF NOT EXISTS `_jabatan` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `jb` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `_jabatan`
--

INSERT INTO `_jabatan` (`id`, `jb`) VALUES
(1, 'Kepala'),
(2, 'Kasubbag Umum'),
(3, 'Kasi'),
(4, 'Staf'),
(5, 'Bendahara');

-- --------------------------------------------------------

--
-- Table structure for table `_jbbm`
--

DROP TABLE IF EXISTS `_jbbm`;
CREATE TABLE IF NOT EXISTS `_jbbm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nbbm` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `_jbbm`
--

INSERT INTO `_jbbm` (`id`, `nbbm`) VALUES
(1, 'Bensin'),
(2, 'Pertalite'),
(3, 'Pertamax'),
(4, 'Solar');

-- --------------------------------------------------------

--
-- Table structure for table `_jk`
--

DROP TABLE IF EXISTS `_jk`;
CREATE TABLE IF NOT EXISTS `_jk` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `jk` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `_jk`
--

INSERT INTO `_jk` (`id`, `jk`) VALUES
(1, 'Laki-laki'),
(2, 'Perempuan');

-- --------------------------------------------------------

--
-- Table structure for table `_kaos`
--

DROP TABLE IF EXISTS `_kaos`;
CREATE TABLE IF NOT EXISTS `_kaos` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `rk` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `_kaos`
--

INSERT INTO `_kaos` (`id`, `rk`) VALUES
(1, 'S'),
(2, 'M'),
(3, 'L'),
(4, 'XL'),
(5, 'XXL'),
(6, 'XXXL'),
(7, '5L');

-- --------------------------------------------------------

--
-- Table structure for table `_kondisi`
--

DROP TABLE IF EXISTS `_kondisi`;
CREATE TABLE IF NOT EXISTS `_kondisi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kondisi` int(1) NOT NULL,
  `nama` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `_kondisi`
--

INSERT INTO `_kondisi` (`id`, `kondisi`, `nama`) VALUES
(1, 1, 'Baik'),
(2, 2, 'Rusak Ringan'),
(3, 3, 'Rusak Berat');

-- --------------------------------------------------------

--
-- Table structure for table `_level`
--

DROP TABLE IF EXISTS `_level`;
CREATE TABLE IF NOT EXISTS `_level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `_level`
--

INSERT INTO `_level` (`id`, `level`) VALUES
(0, 'Administrator'),
(1, 'Supervisor'),
(2, 'User'),
(3, 'Umum');

-- --------------------------------------------------------

--
-- Table structure for table `_pendidikan`
--

DROP TABLE IF EXISTS `_pendidikan`;
CREATE TABLE IF NOT EXISTS `_pendidikan` (
  `id` int(1) NOT NULL,
  `level` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `_pendidikan`
--

INSERT INTO `_pendidikan` (`id`, `level`) VALUES
(1, 'Belum Sekolah'),
(2, 'SD'),
(3, 'SLTP'),
(4, 'SLTA'),
(5, 'Diploma'),
(6, 'S1'),
(7, 'S2'),
(8, 'S3');

-- --------------------------------------------------------

--
-- Table structure for table `_rk`
--

DROP TABLE IF EXISTS `_rk`;
CREATE TABLE IF NOT EXISTS `_rk` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `rk` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `_rk`
--

INSERT INTO `_rk` (`id`, `rk`) VALUES
(1, 'Merokok'),
(2, 'Tidak Merokok');

-- --------------------------------------------------------

--
-- Table structure for table `_tahun`
--

DROP TABLE IF EXISTS `_tahun`;
CREATE TABLE IF NOT EXISTS `_tahun` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `tahun` year(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `_tahun`
--

INSERT INTO `_tahun` (`id`, `tahun`) VALUES
(3, 2010),
(4, 2011),
(5, 2012),
(6, 2013),
(7, 2014),
(8, 2015),
(9, 2016),
(16, 2017),
(17, 2018);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
