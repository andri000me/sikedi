<?php
$_CONFIG['syscopyright'] = "Provinsi Sumatera Utara";
$_CONFIG['sysowner'] = "JRS1200";
$_CONFIG['sysowner2'] = "JRS1200";
$_CONFIG['sysappname'] = "Sistem Informasi Pemakaian Kenderaan Dinas (SIPKD) V.1.3";
$_CONFIG['sysrptname'] = "Sistem Informasi Pemakaian Kenderaan Dinas (SIPKD) V.1.3";
$_CONFIG['slogo'] = "images/fav.png";
$_CONFIG['llogo'] = "../images/bps.png";
$_CONFIG['fslogo'] = "images/bps.png";
$_CONFIG['fllogo'] = "images/bps.png";

$_CONFIG['sysaddress'] = "Jl. Gatot Subroto No. 4";
$_CONFIG['syscity'] = "Medan";
$_CONFIG['syspostal'] = "20xxx";
$_CONFIG['systelp'] = "061-xxxxxx ";
$_CONFIG['sysfax'] = "061-xxxxxx ";
$_CONFIG['sysemail'] = "admin@gmail.com";

$_CONFIG['sysjabatan'] = "Kasie Pengolahan";
$_CONFIG['syspejabat'] = "Dicky Pratama";
$_CONFIG['sysnippejabat'] = "197905102000121003";

$_CONFIG['syscolor'] = "#D15B47";
$_CONFIG['sysrptheight'] = 100;
?>